
# coding: utf-8

# In[37]:


import numpy as np
from scipy import stats
from pandas import DataFrame
from sklearn import linear_model
import statsmodels.api as sm
import matplotlib.pyplot as plt


# In[38]:


A = {'y': [5,7,15,17,9,11],  'X1': [0,0,10,10,20,20],
                'X2': [0,0,100,100,400,400]}


# In[39]:


df = DataFrame(A,columns=['y','X1','X2',])
print (df)


# In[40]:


plt.scatter(df['X1'], df['y'], color='red')
plt.title('y Vs X1', fontsize=14)
plt.xlabel('X1', fontsize=14)
plt.ylabel('y', fontsize=14)
plt.grid(True)
plt.show()
 
plt.scatter(df['X2'], df['y'], color='green')
plt.title('y Vs X2', fontsize=14)
plt.xlabel('X2', fontsize=14)
plt.ylabel('y', fontsize=14)
plt.grid(True)
plt.show()


# In[41]:


X = df[['X1','X2']] # here we have 2 variables for multiple regression. If you just want to use one variable for simple linear regression, then use X = df['fert'] for example.Alternatively, you may add additional variables within the brackets
Y = df['y']


# In[42]:


regr = linear_model.LinearRegression()
regr.fit(X, Y)


# In[43]:


print('Intercept: \n', regr.intercept_)
print('Coefficients: \n', regr.coef_)


# In[44]:


# prediction with sklearn
New_X1 = 0
New_X2 = 0
print ('Predicted yeild: \n', regr.predict([[New_X1 ,New_X2]]))


# In[45]:


# with statsmodels
X = sm.add_constant(X) # adding a constant
 
model = sm.OLS(Y, X).fit()
predictions = model.predict(X) 


# In[46]:


print_model = model.summary()
print(print_model)


# In[47]:


# Define 2 random distributions
#Sample Size
N = 7
#Gaussian distributed data with mean = 2 and var = 1
a = np.random.randn(N) + 2
#Gaussian distributed data with with mean = 0 and var = 1
b = np.random.randn(N)


## Calculate the Standard Deviation
#Calculate the variance to get the standard deviation

#For unbiased max likelihood estimate we have to divide the var by N-1, and therefore the parameter ddof = 1
var_a = a.var(ddof=1)
var_b = b.var(ddof=1)

#std deviation
s = np.sqrt((var_a + var_b)/2)
s



## Calculate the t-statistics
t = (a.mean() - b.mean())/(s*np.sqrt(2/N))


## Compare with the critical t-value
#Degrees of freedom
df = 2*N - 2

#p-value after comparison with the t 
p = 1 - stats.t.cdf(t,df=df)


print("t = " + str(t))
print("p = " + str(2*p))
#Note that we multiply the p value by 2 because its a twp tail t-test
### You can see that after comparing the t statistic with the critical t value (computed internally) we get a good p value of 0.0005 and thus we reject the null hypothesis and thus it proves that the mean of the two distributions are different and statistically significant.


## Cross Checking with the internal scipy function
t2, p2 = stats.ttest_ind(a,b)
print("t = " + str(t2))
print("p = " + str(2*p2))

