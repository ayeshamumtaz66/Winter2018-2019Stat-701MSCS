#multiple Linear Regression
y <- c(5,7,15,17,9,11)
X1 <- c(0,0,10,10,20,20)
X2 <- c(0,0,100,100,400,400)
mean(y)
mean(X1)
mean(X2)
hist(X1)
summary(X1,X2)

Regression <- lm(y ~ X1 + X2)

print(summary(Regression))
reduced <- lm(X1 ~ X2)
full <- lm(y ~ X1 + X2)
anova(reduced,full)
#prediction (default=95% confidence)
predict(Regression,data.frame(y=7),interval = 'confidence')

