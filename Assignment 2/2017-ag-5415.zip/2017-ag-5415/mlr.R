#multiple Linear Regression
yield <- c(40,50,50,70,65,65,80)
fert <- c(100,200,300,400,500,600,700)
rainfall <- c(10,20,10,30,20,20,30)
mean(yield)
mean(fert)
mean(rainfall)
hist(fert)
summary(fert,rainfall)
 
Regression <- lm(yield ~ fert + rainfall)

print(summary(Regression))
reduced <- lm(fert ~ rainfall)
full <- lm(yield ~ fert + rainfall)
anova(reduced,full)
#prediction (default=95% confidence)
predict(Regression,data.frame(yeild=7),interval = 'confidence')

